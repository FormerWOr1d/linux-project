# Copyright (c) 2017-2026, University of Cincinnati, developed by Henry Schreiner
# under NSF AWARD 1414736 and by the respective contributors.
# All rights reserved.
#
# SPDX-License-Identifier: BSD-3-Clause

if(CLI11_PRECOMPILED)
  # Create library default is static
  file(GLOB CLI11_precompile_sources "${PROJECT_SOURCE_DIR}/src/*.cpp")
  add_library(CLI11 ${CLI11_headers} ${CLI11_library_headers} ${CLI11_impl_headers}
                    ${CLI11_precompile_sources})
  target_compile_definitions(CLI11 PUBLIC CLI11_COMPILE)

  set(PUBLIC_OR_INTERFACE PUBLIC)
else()
  add_library(CLI11 INTERFACE)
  if(CMAKE_VERSION VERSION_GREATER_EQUAL 3.19)
    # This is only useful for visual studio and other IDE builds
    target_sources(CLI11 PRIVATE ${CLI11_headers} ${CLI11_library_headers} ${CLI11_impl_headers})

  endif()

  set(PUBLIC_OR_INTERFACE INTERFACE)
endif()

if(CLI11_ENABLE_EXTRA_VALIDATORS)
  target_compile_definitions(CLI11 ${PUBLIC_OR_INTERFACE} CLI11_ENABLE_EXTRA_VALIDATORS=1)
elseif(CLI11_DISABLE_EXTRA_VALIDATORS)
  target_compile_definitions(CLI11 ${PUBLIC_OR_INTERFACE} CLI11_DISABLE_EXTRA_VALIDATORS=1)
elseif(DEFINED CLI11_ENABLE_EXTRA_VALIDATORS)
  target_compile_definitions(CLI11 ${PUBLIC_OR_INTERFACE} CLI11_ENABLE_EXTRA_VALIDATORS=0)
endif()
# Allow IDE's to group targets into folders
add_library(CLI11::CLI11 ALIAS CLI11) # for add_subdirectory calls

if(CMAKE_PROJECT_NAME STREQUAL PROJECT_NAME)
  set(SYSTEM_INCL "")
else()
  # If this project is included from somewhere else, we mark our headers as system headers to avoid
  # the compiler emitting any warnings about them
  set(SYSTEM_INCL "SYSTEM")
endif()

# Duplicated because CMake adds the current source dir if you don't.
target_include_directories(
  CLI11 ${SYSTEM_INCL} ${PUBLIC_OR_INTERFACE} $<BUILD_INTERFACE:${PROJECT_SOURCE_DIR}/include>
  $<INSTALL_INTERFACE:include>)

if(CMAKE_CXX_STANDARD LESS 14)
  target_compile_features(CLI11 INTERFACE cxx_std_11)
endif()

if(WIN32)
  target_link_libraries(CLI11 ${PUBLIC_OR_INTERFACE} shell32)
endif()

if(CLI11_INSTALL OR CLI11_FULL_INSTALL)

  # Make an export target
  install(TARGETS CLI11 EXPORT CLI11Targets)
  if((NOT CLI11_SINGLE_FILE) OR CLI11_FULL_INSTALL)
    install(FILES ${CLI11_headers} ${CLI11_library_headers}
            DESTINATION "${CMAKE_INSTALL_INCLUDEDIR}/CLI")
    if(NOT (CLI11_DISABLE_IMPL_HEADERS_INSTALL AND CLI11_PRECOMPILED))
      install(FILES ${CLI11_impl_headers} DESTINATION "${CMAKE_INSTALL_INCLUDEDIR}/CLI/impl")
    endif()
  endif()
endif()

if(CLI11_MODULES)
  add_subdirectory(modules)
endif()
